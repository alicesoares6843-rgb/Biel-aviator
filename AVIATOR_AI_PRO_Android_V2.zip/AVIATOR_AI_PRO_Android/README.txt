AVIATOR AI PRO - PROJETO ANDROID 2.0

Este pacote contém o projeto-fonte Android (WebView) e a interface HTML local.
Não é um APK já compilado.

COMO GERAR O APK:
1. Instale o Android Studio no computador.
2. Extraia este ZIP.
3. No Android Studio, escolha Open e selecione a pasta AVIATOR_AI_PRO_Android.
4. Aguarde a sincronização do Gradle e a instalação dos componentes Android solicitados.
5. Abra Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.

O app não precisa de conta ou conexão para suas funções estatísticas locais.
A importação de imagem permite selecionar e visualizar o print; a leitura automática OCR ainda não está implementada.
Os cálculos descrevem apenas o histórico inserido e não predizem resultados futuros.
