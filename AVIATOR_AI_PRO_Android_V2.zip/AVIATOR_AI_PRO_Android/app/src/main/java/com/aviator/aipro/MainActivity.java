package com.aviator.aipro;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> upload;
 private final static int PICK=1001;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p){
    if(upload!=null)upload.onReceiveValue(null);upload=cb;
    Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(Intent.createChooser(i,"Escolher imagem"),PICK);return true;
   }
  });
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);
  if(req==PICK&&upload!=null){Uri[] out=null;if(res==RESULT_OK&&data!=null&&data.getData()!=null)out=new Uri[]{data.getData()};upload.onReceiveValue(out);upload=null;}
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
